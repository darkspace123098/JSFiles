import {add} from './add.js';
console.log(add(2,3)); 