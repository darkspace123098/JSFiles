const person = {
    name:'Mukesh',
    age:22,
    greet(){
        console.log(`Heloo,my name is ${this.name} and I am ${this.age} years old.`);
    }
};
export {person};