import { person } from "./person.js";

console.log(person.name);
person.greet();