import multiply from './multiply.js';
console.log(multiply(4,3));