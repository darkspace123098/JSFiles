export default function multiply(a,b){
    return a*b
}