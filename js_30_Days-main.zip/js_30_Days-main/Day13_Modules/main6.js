import _ from 'lodash';
const array=[1,2,3,4,5];
const shuffledArray = _.shuffle(array);
console.log(shuffledArray);