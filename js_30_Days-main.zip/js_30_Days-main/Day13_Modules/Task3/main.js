import { add , sub} from './math.js';

console.log(add(5,3));
console.log(sub(5,3));