import * as utils from './utils.js';
console.log(utils.PI);
console.log(utils.area(5));
console.log(utils.circumference(5));;