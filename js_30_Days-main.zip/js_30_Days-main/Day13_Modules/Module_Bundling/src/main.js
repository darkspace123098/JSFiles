import { add } from './add.js';
import { person } from './person.js';

console.log(add(2, 3)); 
person.greet(); 