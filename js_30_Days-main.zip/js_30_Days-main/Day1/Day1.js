// Task 1
//     var num = 5;
//     let str = "Mukesh";
//     console.log(num);
//     console.log(str);

// Task 2
//     const bool = true;
//     console.log(bool);

// Task 3
//     let arr = [1, 2, 3, 4, 5];
//     console.log(arr.length);

// Task 4
// Create variables of different data types (number, string, boolean, object, array) and log each variable's type using the typeof operator.
//     const num = 56;
//     console.log(typeof(num));

//     const str = "kumar";
//     console.log(typeof(str));

//     const bool=true;
//     console.log(typeof(bool));

//     const bus={
//         number:123,
//         color:"red",
//         driver:"John Doe"
//     }
    
//     console.log(typeof(bus));


//     const arr=[1,2,3,4];
//     console.log(typeof(arr)); //Logs: object (arrays are a type of object in JavaScript)


// Task 5
// Declare a variable using let , assign it an initial value, reassign a new value, and log both values to the console.
//        let num = 5;
//        console.log(num);

//        num =10;
//        console.log(num);

// Task 6
// Try reassigning a variable declared with const and observe the error.
   
//      const num = 1;
//      console.log(num);
//       num =2;
//     console.log(num);